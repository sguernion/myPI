# Plugin Marantz For Yana-Server

Plugin pour ajouter les commandes vocales qui permettent de commander un amplicifacteur Marantz

## Features


## TODO
